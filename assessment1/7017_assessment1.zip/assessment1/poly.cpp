#include "Poly.h"

bool Poly::polyGenerated = false;
unsigned int Poly::polygonEboID1, Poly::polygonVBOID1, Poly::polygonVaoID1;


Poly::Poly()
{
	//vertix for the polygon
	float polygonVertices[] = {

		0.0,0.6,0,  1,0,1,//top
		0.5,0.2,0,  0,1,0,//mid right
		0.8,-0.5,0, 1,0,1, //bottom right
		0.0,-0.5,0, 0,1,0, //bottom mid
		-0.8,-0.5,0,1,0,1, //bottom left
		-0.5,0.2,0, 0,1,0 //mid left
	};



	//order of indexes from above vertices of 4 triangles
	unsigned int polygonIndices[] = {
		1,2,3,//second triangle
		0,1,3,//first triangle
		0,3,5,//thrid triangle
		3,4,5//second triangle
	};

	//polygon VAO
	glGenVertexArrays(1, &polygonVaoID1);

	glBindVertexArray(polygonVaoID1);

	//id of the polygon vertext buffer
	glGenBuffers(1, &polygonVBOID1);
	//make this buffer the active one
	glBindBuffer(GL_ARRAY_BUFFER, polygonVBOID1);
	//put data into it
	glBufferData(GL_ARRAY_BUFFER, sizeof(polygonVertices), polygonVertices, GL_STATIC_DRAW);


	//Elemental Buffer object(EBO) which holds the indexes of vertexes to help build triangles
	glGenBuffers(1, &polygonEboID1);
	//make it the current buffer
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, polygonEboID1);
	//give it the data
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(polygonIndices), polygonIndices, GL_STATIC_DRAW);

	//bind rect Ebo
	//glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, polygonEboID1);

	//feed polygon Buffer Data into vertex shader. 
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	//enable location 0
	glEnableVertexAttribArray(0);

	///*
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	//enable location 1
	glEnableVertexAttribArray(1);
//*/
	//unbind VAO
	glBindVertexArray(0);



	//unbind VAO
	glBindVertexArray(0);
}


Poly::~Poly()
{
}

void Poly::draw()
{
	shader->use();
	
	

	//bind vao to make this shape current
	glBindVertexArray(polygonVaoID1);

	glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);


}

