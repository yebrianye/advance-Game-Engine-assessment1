#pragma once
#include "Shader.h"
#include <GLFW\glfw3.h>

class Poly
{
public:

	Shader* shader;
	static bool polyGenerated;
	static unsigned int polygonEboID1, polygonVBOID1, polygonVaoID1;

	Poly();
	virtual ~Poly();

	void draw();
};

